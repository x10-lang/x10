The fft implementation is a hybrid of X10 and c codes. It calls fftw which can be downloaded
at (fftw-3.1.2.tar.gz)
       http://www.fftw.org/download.html 