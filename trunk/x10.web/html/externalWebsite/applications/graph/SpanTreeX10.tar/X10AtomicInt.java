import java.util.concurrent.atomic.AtomicInteger;

public class X10AtomicInt extends AtomicInteger {
	public X10AtomicInt() {
		super();
	}
	public X10AtomicInt(int v) {
		super(v);
	}
}
