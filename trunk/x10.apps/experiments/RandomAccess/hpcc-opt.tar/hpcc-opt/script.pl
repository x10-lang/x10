#!/usr/bin/perl
    
    use POSIX qw (ceil floor);

    open(INPUT, "_hpccinf.txt") or die( "Error: cannot open file $SCRATCH" );
    $comment = 0;
    $ifdef = 0;
    while( $aline = <INPUT> ){
	$inputline = $inputline.$aline;
    }
    close(INPUT);

    $inputsize = ceil(sqrt(2 ** ($ARGV[1] + log2($ARGV[0]))));
    $tmp = $inputline;
    $inputline = $tmp;
    $inputline =~ s/1            Ps/$ARGV[0]           Ps/g;
    $inputline =~ s/1            Ns/$inputsize         Ns/g;
    $filename = "hpccinf.txt"; 
    open(OUTPUT, ">$filename") or die( "unable to open $filename" );
    print OUTPUT $inputline;
    close(OUTPUT);   
    `rm hpccoutf.txt`;
    `poe ./hpcc -procs $ARGV[0]`;


open(INPUT, "hpccoutf.txt") or die( "Error: cannot open file $SCRATCH" );
$skip=1;
while( $aline = <INPUT> ){

 if ($aline =~ /Begin of MPIRandomAccess/ ){
    $skip = 0;
 }
  if ($skip =~ 0) {
    print $aline; 
  } 
 
 if ($aline =~ /End of MPIRandomAccess/ ){
    $skip = 1;
  }
 
}

close(INPUT);

sub log2 {

    $log = 0;

    my($start) = shift (@_);

    while ($start > 1) {

        $log = $log + 1;
        $start = $start / 2;
    }

    return ($log);
}



