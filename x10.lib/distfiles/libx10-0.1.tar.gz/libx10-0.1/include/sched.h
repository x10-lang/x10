/*
 * (c) Copyright IBM Corporation 2007
 *
 * $Id: sched.h,v 1.1.1.1 2007/04/25 09:57:46 srkodali Exp $
 * This file is part of X10 Runtime System.
 */

/** Sample scheduler header file **/

#ifndef __X10_SCHED_H
#define __X10_SCHED_H

int sched_sample(void);

#endif /* __X10_SCHED_H */
