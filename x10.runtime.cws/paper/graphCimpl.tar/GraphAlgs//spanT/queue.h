#ifndef _MY_QUEUE_H_
#define _My_QUEUE_H_
void enQ(int r, int * Q, int *p_tail);
int deQ(int * Q, int *p_head, int * p_tail);
#endif
