#include "simple.h"
#include "graph.h"
#include "locksMacros.il"

#define DEBUG_CORRECTNESS 1 

#if 0 
int spin_lock(int * plock, int id)
{
  int y;
  while( (y=backoffLock(plock)) == -1 );
}
 int spin_unlock(int *plock)
 {
   *plock=0;
 }
#endif

int spanning_tree_CRCW_spinlock(V* graph,E* El, int nVertices,int n_edges,THREADED)
{
  int *p_changed,*buffer,*D,*assign,*done,changed,i,j,n,s=0,l=0,t=0,iter_count=0;
  V * tree;
  E *El_tmp;
  int *lock_array;

#if DEBUG_TIMING
  hrtime_t start,end;
  double interval1=0,interval2=0,interval3=0;
#endif

#if DEBUG_CORRECTNESS
  int edge_count=0;
#endif
  
  p_changed=node_malloc(sizeof(int),TH);
  on_one_thread (*p_changed)=1;

  D=node_malloc(sizeof(int)*nVertices,TH); /*used for Di*/
  done=node_malloc(sizeof(int)*nVertices,TH);
  lock_array = node_malloc(sizeof(int)*nVertices,TH);
  
  pardo(i,0,nVertices,1) /*initialize the D values, Jaja p217*/
    {     
      done[i]=0;
      D[i]=i;
      lock_array[i]=0;
    }

  node_Barrier();
  while((*p_changed)==1)
    {
      iter_count++;
      node_Barrier();

      /*1. phase one*/
      on_one_thread (*p_changed)=0;
      changed=0;

      node_Barrier();

    pardo(n,0,n_edges,1)
	{
	  if(El[n].workspace==1) continue;
	  i=El[n].v1;
	  j=El[n].v2;
      
	  if(D[j]<D[i] && D[i]==D[D[i]] && done[D[i]]==0)
	    {
		  t = spin_lock_i(&(lock_array[D[i]]), MYTHREAD+1);
		  l ++;
		  s += t;
		  if(done[D[i]]==0){
		  	done[D[i]]=1;
			spin_unlock(&(lock_array[D[i]]));
	        	changed=1;
		    	El[n].workspace=1;
	        	D[D[i]]=D[j];
#if DEBUG_CORRECTNESS
	        edge_count++;
#endif
	     	}else spin_unlock(&(lock_array[D[i]]));
   	  }
	}

    if(changed) (*p_changed)=1;
      node_Barrier();
      
     /*3.phase 3*/	
    pardo(i,0,nVertices,1)
	{
	  while(D[i]!=D[D[i]]) D[i]=D[D[i]];
    }
    node_Barrier();

    } /*while*/

#if DEBUG_CORRECTNESS
    node_Barrier();
    pardo(i,0,nVertices,1)
    {
	 if(D[i]!=D[0] ){
	   printf("ERROR in SPANNING TREE:D[0]=%d, D[%d]=%d\n", D[0], i, D[i]);
	   break;
	 }
    }
#endif

    on_one printf("number of iterations:%d\n",iter_count);
    printf(" THREAD %d : l = %d, s = %d\n", MYTHREAD,l, s);
    l = node_Reduce_i(l, SUM, TH);
    s = node_Reduce_i(s, SUM, TH);
    on_one printf("lock sum = %d, try times = %d, succ rate = %f \n", l, s, (float) l / (float) s); 
#if DEBUG_CORRECTNESS
	edge_count = node_Reduce_i(edge_count,SUM,TH);
    on_one printf("Total edges got is %d\n",edge_count);
#endif

    node_free(p_changed,TH);
    node_free(D,TH);
    node_free((void*)lock_array,TH);
    node_free(done,TH);
}
