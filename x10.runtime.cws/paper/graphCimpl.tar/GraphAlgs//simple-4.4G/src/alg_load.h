#ifndef _ALG_LOAD_H
#define _ALG_LOAD_H

double get_load();
#if 0
void partition_work(int n, int *part);
#endif

#endif

