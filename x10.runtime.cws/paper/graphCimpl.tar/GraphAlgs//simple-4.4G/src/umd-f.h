#ifndef _UMD_F_H
#define _UMD_F_H

#define on_one_node if (mynode .eq 0)
#define on_node(a)  if (mynode .eq. (a))

#endif

