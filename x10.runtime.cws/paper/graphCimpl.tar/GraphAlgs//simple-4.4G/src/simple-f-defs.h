#ifndef SIMPLE_F_DEFS_H
#define SIMPLE_F_DEFS_H

#define FTHSIZE 8

#define OP_MAX    1
#define OP_MIN    2
#define OP_SUM    3
#define OP_PROD   4
#define OP_LAND   5
#define OP_BAND   6
#define OP_LOR    7
#define OP_BOR    8
#define OP_LXOR   9
#define OP_BXOR  10

#endif

