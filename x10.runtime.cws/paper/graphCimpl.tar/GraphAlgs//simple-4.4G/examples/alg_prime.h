#ifndef _ALG_PRIME_H
#define _ALG_PRIME_H

#include "simple.h"

void all_prime_mpi();
void all_prime(THREADED);

#endif

