#ifndef _ALG_CREATE_INPUT_H
#define _ALG_CREATE_INPUT_H

#include "simple.h"

void create_input_nas_smp(int n, int *x, THREADED);
void create_input_random_smp(int myN, int *x, THREADED);

#endif
